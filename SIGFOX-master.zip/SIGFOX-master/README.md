SIGFOX-HackerspaceSG-Pilot
==========================

A repository whose main focus will be the wiki which contains information which can help new enthusiasts get onboard and get started using the new Akeru devices provided by Singtel :)
